-- phpMyAdmin SQL Dump
-- version 3.2.3
-- http://www.phpmyadmin.net
--
-- 호스트: localhost
-- 처리한 시간: 20-11-24 16:44 
-- 서버 버전: 5.1.41
-- PHP 버전: 5.2.12

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `MovieResrv`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `review`
--

CREATE TABLE IF NOT EXISTS `review` (
  `name` varchar(15) NOT NULL,
  `roll` varchar(50) NOT NULL,
  `writedate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `review`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `ticket`
--

CREATE TABLE IF NOT EXISTS `ticket` (
  `title` varchar(25) NOT NULL,
  `id` varchar(15) NOT NULL,
  `time` datetime NOT NULL,
  `seat` varchar(15) NOT NULL,
  `theater` varchar(15) NOT NULL,
  UNIQUE KEY `seat` (`seat`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `ticket`
--


-- --------------------------------------------------------

--
-- 테이블 구조 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` varchar(15) NOT NULL,
  `passwd` varchar(15) NOT NULL,
  `name` varchar(15) NOT NULL,
  `phone` int(15) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 테이블의 덤프 데이터 `user`
--

